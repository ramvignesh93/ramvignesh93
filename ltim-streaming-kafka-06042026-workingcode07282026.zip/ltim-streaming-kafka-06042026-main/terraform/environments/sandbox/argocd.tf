# AWS Load Balancer Controller — required for NLB subnet annotation support
resource "helm_release" "aws_load_balancer_controller" {
  name       = "aws-load-balancer-controller"
  repository = "https://aws.github.io/eks-charts"
  chart      = "aws-load-balancer-controller"
  version    = "1.8.1"
  namespace  = "kube-system"
  timeout    = 300
  wait       = true

  set {
    name  = "clusterName"
    value = module.eks.cluster_id
  }

  set {
    name  = "serviceAccount.create"
    value = "true"
  }

  set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com/role-arn"
    value = module.iam_oidc.aws_load_balancer_controller_role_arn
  }

  set {
    name  = "region"
    value = var.aws_region
  }

  set {
    name  = "vpcId"
    value = data.aws_vpc.main.id
  }

  depends_on = [
    module.eks,
    module.iam_oidc
  ]
}

# ArgoCD Installation
resource "kubernetes_namespace" "argocd" {
  metadata {
    name = "argocd"
    labels = {
      "app.kubernetes.io/managed-by" = "Terraform"
    }
  }
  depends_on = [module.eks]
}

resource "helm_release" "argocd" {
  name            = "argocd"
  repository      = "https://argoproj.github.io/argo-helm"
  chart           = "argo-cd"
  version         = "7.7.11"
  namespace       = kubernetes_namespace.argocd.metadata[0].name
  timeout         = 600
  wait            = false
  cleanup_on_fail = true

  values = [
    yamlencode({
      server = {
        extraArgs = ["--insecure"]
        resources = {
          requests = {
            cpu    = "100m"
            memory = "128Mi"
          }
        }
        service = {
          type = "ClusterIP"    # Changed from LoadBalancer
        }
        ingress = {
          enabled = true
          ingressClassName = "alb"
          annotations = {
            "kubernetes.io/ingress.class"                          = "alb"
            "alb.ingress.kubernetes.io/scheme"                     = "internet-facing"
            "alb.ingress.kubernetes.io/target-type"                = "ip"
            "alb.ingress.kubernetes.io/load-balancer-name"        = "ltim-sandbox-alb"
            "alb.ingress.kubernetes.io/group.name"                 = "ltim-sandbox"
            "alb.ingress.kubernetes.io/subnets"                    = "subnet-029bd5314cc6be43b,subnet-06f932637b153d140,subnet-00ffd8ba8d06d2f1b"
            "alb.ingress.kubernetes.io/listen-ports"               = "[{\"HTTP\":80}]"
            "alb.ingress.kubernetes.io/healthcheck-path"           = "/healthz"
            "alb.ingress.kubernetes.io/success-codes"              = "200"
          }
          hosts = ["argocd.ltm.in"]
        }
      }
      repoServer = {
        resources = {
          requests = {
            cpu    = "100m"
            memory = "128Mi"
          }
        }
      }
      applicationSet = {
        resources = {
          requests = {
            cpu    = "100m"
            memory = "128Mi"
          }
        }
      }
      configs = {
        cm = {
          "application.resourceTrackingMethod" = "annotation"
        }
        secret = {
          githubSecret = "6f1ef1f99dbc09de290676e4dcad3c9e48865caa"
        }
      }
    })
  ]

  depends_on = [
    kubernetes_namespace.argocd,
    module.eks,
    module.iam_oidc,
    helm_release.aws_load_balancer_controller
  ]
}

# ECR repositories for portal images
resource "aws_ecr_repository" "kafka_portal_api" {
  name                 = "kafka-portal-api"
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  tags = local.common_tags
}

resource "aws_ecr_repository" "kafka_portal_ui" {
  name                 = "kafka-portal-ui"
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  tags = local.common_tags
}